public class Cat {
    
    private int row;
    private int col;
    private int appetite;
    private int numMiceEaten;
    
    /** 
    * Sets row, col, and appetite based on the inputs.
    * Sets numMiceEaten to 0.
    */
    public Cat(int r, int c, int a) {
        row = r;
        col = c;
        appetite = a;
        numMiceEaten = 0;
    }
    
    /**
    * If the cat has already filled its appetite or all the mice have already been eaten, do nothing.
    * Chooses one not-yet-eaten Mouse from the input array as the target and moves towards that Mouse.
    * The cat is allowed to move up, down, left, right, or diagonally one space.
    * After the move, eat any mice that are at the cat's location.
    */
    public void chaseMice(Mouse[] mice) {
        boolean f = true;
        double small = 0;
        int smallIndex = 0;
        
        for(int i = 0; i < mice.length; i++){
            if(!mice[i].isEaten()){
                int x = mice[i].getRow() - row;
                int y = mice[i].getCol() - col;
                x = x*x;
                y = y*y;
                double sum = x + y;
                double distance = Math.sqrt(sum);
                if(f){
                    f = false;
                    small = distance;
                    smallIndex = i;
                }
                if(distance < small){
                    small = distance;
                    smallIndex = i;
                }
            }
        }
       
        if(row == mice[smallIndex].getRow() && col == mice[smallIndex].getCol()){  
            mice[smallIndex].beEaten();
            numMiceEaten++;
            return;
        }
        else if(row == mice[smallIndex].getRow()){
            if(row < mice[smallIndex].getCol())
                col++;
            else
                col--;
        }
        else if(col == mice[smallIndex].getCol()){
            if(row < mice[smallIndex].getRow())
                row++;
            else
                row--;
        }
        else if(row < mice[smallIndex].getRow() && col < mice[smallIndex].getCol()){
            row++;
            col++;
        }
        else if(row > mice[smallIndex].getRow() && col < mice[smallIndex].getCol()){
            row--;
            col++;
        }
        else if(row < mice[smallIndex].getRow() && col > mice[smallIndex].getCol()){
            row++;
            col--;
        }
        else if(row > mice[smallIndex].getRow() && col > mice[smallIndex].getCol()){
            row--;
            col--;
        }
        if(row == mice[smallIndex].getRow() && col == mice[smallIndex].getCol()){
            mice[smallIndex].beEaten();
            numMiceEaten++;
        }
    }
    
    
    // Returns the cat's row.
    public int getRow() {
        return row;
    }
    
    // Returns the cat's column.
    public int getCol() {
        return col;
    }
}